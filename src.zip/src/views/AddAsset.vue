
<template>
<v-form>
  <v-container align-center>
<div>
<v-text-field v-model="asset.assetId" label="Asset ID" required></v-text-field><br>
<v-combobox v-model="asset.assetType" :items="users" label="Asset Type"></v-combobox><br>
<v-combobox v-model="asset.assetCat" :items="items[asset.assetType]" label="Asset Category"></v-combobox><br>
<v-text-field v-model="asset.assetTitle" label="Asset Title" required></v-text-field><br>
<v-text-field v-model="asset.assetDescp" label="Asset Description" required></v-text-field><br>
<v-text-field v-model="asset.projectId" label="Project ID" required></v-text-field><br>
<v-text-field v-model="asset.managerId" label="Project Manager ID" required></v-text-field><br>
<v-text-field v-model="asset.assetAttach" label="Asset Attachment" required></v-text-field><br>
<v-text-field v-model="asset.effortSavings" label="Estimated Effort savings on reuse" required></v-text-field><br>
<v-text-field v-model="asset.dollarSavings" label="Estimated Dollar savings on reuse" required></v-text-field><br>
<v-text-field v-model="asset.owners" label="Asset Owner(s)" required></v-text-field><br>
<v-btn rounded color="primary" dark>Cancel</v-btn>
<v-btn rounded color="primary" dark @click="addData()">Submit</v-btn> 
</div>
  </v-container>
</v-form>
</template>

<script>
//import {assetRef} from './firebase';
export default{
 
  data(){
    return{
       asset:{
        assetId:'',
        assetTitle:'',
        assetDescp:'',
        projectId:'',
        managerId:'',
        assetAttach:'',
        effortSavings:'',
        dollarSavings:'',
        assetType:'',
        assetCat:'',
        owners:'',
        assetStatus:''
      },
     users:["Code","Tool","Process","Knowledge","Testing"],
      items: {
          "Code":['Front end','Web Services','Utilities','Framework','Design','Automation'],
          "Tool":['CTS proprietary','Third party','Automation','In-house'],
          "Process":['Dev Ops','Agile','Support','Automation','Trackers','Checklists'],
          "Knowledge":['Domain','Functional','Technical','Testing','Automation'],
          "Testing":['Test case automation','Test Framework','Test tools']
    }}
  },
  methods:{
   addData(){
     this.$http.post('https://neeusable.firebaseio.com/asset.json',this.asset)
     .then(response =>{
       console.log(response);
     },
     error =>{
       console.log(error);
     })
   }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>

</style>