<template>
    <div align="center">
    <v-form>
    <v-container>
      <v-row>

        <v-col cols="12" sm="6">
          <v-text-field
            v-model="accname"
            label="Account Name"
            filled
          ></v-text-field>
        </v-col>

        <v-col cols="12" sm="6">
          <v-text-field
            v-model="projectid"
            label="Project ID"
            filled
          ></v-text-field>
        </v-col>
        <v-col cols="12" sm="6">
         <v-combobox
          v-model="asset.assetType"
          
          :items="users"
          label="Asset Type"
        ></v-combobox>
        </v-col>
        <v-col cols="12" sm="6">
          <v-combobox 
          v-model="assetCat"
          
          :items="items[asset.assetType]"
          label="Asset Category"
        ></v-combobox>
        </v-col>
         
            <v-btn text icon color="green" @click="getSomething()">
              <v-icon>mdi-cached</v-icon>
            </v-btn>
          
      </v-row>
      <v-btn rounded color="primary" dark>Download Assets</v-btn>
      <v-btn rounded color="primary" dark @click="$router.push('/reports')">View Reports</v-btn>
     </v-container>
  </v-form>
 <v-simple-table height="300px">
    <template v-slot:default>
     
      <thead>
        <tr>
          <th></th>
      <th>Asset ID</th>
      <th>Asset Title</th>
      <th>Asset Description</th>
      <th>Asset Owner Name</th>
      <th>Asset Status</th>
      <th></th>
      <th></th>
        </tr>
      </thead>
      <tbody>
        <tr>
         <td><input type="checkbox" value="true"/></td>
        <td>{{assets.assetId}}</td>
        <td>{{assets.assetTitle}}</td>
        <td>{{assets.assetDescp}}</td>
        <td>{{assets.owners}}</td>
        <td>{{assets.assetStatus}}</td>
        <td><v-btn small color="primary" dark @click="$router.push('/consumeasset')">View Details</v-btn></td>
        <td><v-btn small color="primary" dark>Edit</v-btn></td>
        </tr>
      </tbody>
    </template>
  </v-simple-table>
  </div>
   
 
</template>

<script>
//import ATable from '../components/ATable';

export default {
  data(){
   
   return{
      assets:[],
      asset:{
        assetId:'',
        assetTitle:'',
        assetDescp:'',
        projectId:'',
        managerId:'',
        assetAttach:'',
        effortSavings:'',
        dollarSavings:'',
        assetType:'',
        assetCat:'',
        owners:'',
        assetStatus:''
      },
     users:["Code","Tool","Process","Knowledge","Testing"],
      items: {
          "Code":['Front end','Web Services','Utilities','Framework','Design','Automation'],
          "Tool":['CTS proprietary','Third party','Automation','In-house'],
          "Process":['Dev Ops','Agile','Support','Automation','Trackers','Checklists'],
          "Knowledge":['Domain','Functional','Technical','Testing','Automation'],
          "Testing":['Test case automation','Test Framework','Test tools']
      }
   }
  },
 created(){
   //users:[];
   
  },
  methods:{
    getSomething(){
      //const assets=[];
      //this.users=resultArray;
      //console.log(users);
       this.$http.get('https://neeusable.firebaseio.com/asset.json')
    .then(response=>{
      return response.json();
      //console.log(response.json());
    })
    .then(data=>{
      const resultArray=[];
      for(let key in data){
        resultArray.push(data[key]);
      }
      this.assets=resultArray;
      console.log('',this.assets);
    })
      }
    }
  }
  

</script>
