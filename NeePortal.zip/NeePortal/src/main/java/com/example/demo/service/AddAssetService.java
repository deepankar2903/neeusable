package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Asset;
import com.example.demo.model.Home;

public interface AddAssetService {

	Asset save(Asset asset);
	
	Asset update(Asset asset);
	
	List<Asset> getAllAsset();

	Asset getAsset(String assetId);
}
