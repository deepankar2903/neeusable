package com.example.demo.model;

public @interface GenericGenerator {

}
