package com.example.demo.model;

import javax.annotation.Generated;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "NeeCollection")
public class Asset {

	@Id
//    @GeneratedValue(strategy = Generated.SEQUENCE, generator = "book_seq")
//	  @GenericGenerator(
//	        name = "book_seq", 
//	        strategy = "org.thoughts.on.java.generators.StringPrefixedSequenceIdGenerator", 
//	        parameters = {
//	            @Parameter(name = StringPrefixedSequenceIdGenerator.INCREMENT_PARAM, value = "001"),
//	            @Parameter(name = StringPrefixedSequenceIdGenerator.VALUE_PREFIX_PARAMETER, value = "NEE_AID_") }),
	       //@Parameter(name = StringPrefixedSequenceIdGenerator.NUMBER_FORMAT_PARAMETER, value = "%05d") })
	
//	
//	 @GeneratedValue(generator = "sequence-generator")
//   // @GenericGenerator(
//      name = "sequence-generator",
//      strategy = "org.hibernate.id.enhanced.SequenceStyleGenerator",
//      parameters = {
//        @Parameter(name = "sequence_name", value = "user_sequence"),
//        @Parameter(name = "initial_value", value = "4"),
//        @Parameter(name = "increment_size", value = "1")
//        }
//    )
	private String assetId;

	@Field(value = "assetTitle")
	private String assetTitle;

	@Field(value = "assetDescp")
	private String assetDescp;

	@Field(value = "projectId")
	private String projectId;

	@Field(value = "managerId")
	private String managerId;

	@Field(value = "assetAttach")
	private String assetAttach;

	@Field(value = "effortSavings")
	private String effortSavings;

	@Field(value = "dollarSavings")
	private String dollarSavings;
	
	@Field(value = "assetType")
	private String assetType;

	@Field(value = "assetCat")
	private String assetCat;

	@Field(value = "owners")
	private String owners;

	@Field(value = "assetStatus")
	private String assetStatus;

	public Asset() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Asset(String assetId, String assetTitle, String assetDescp, String projectId, String managerId,
			String assetAttach, String effortSavings, String dollarSavings, String assetType, String assetCat,
			String owners, String assetStatus) {
		super();
		this.assetId = assetId;
		this.assetTitle = assetTitle;
		this.assetDescp = assetDescp;
		this.projectId = projectId;
		this.managerId = managerId;
		this.assetAttach = assetAttach;
		this.effortSavings = effortSavings;
		this.dollarSavings = dollarSavings;
		this.assetType = assetType;
		this.assetCat = assetCat;
		this.owners = owners;
		this.assetStatus = assetStatus;
	}

	public String getAssetId() {
		return assetId;
	}

	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}

	public String getAssetTitle() {
		return assetTitle;
	}

	public void setAssetTitle(String assetTitle) {
		this.assetTitle = assetTitle;
	}

	public String getAssetDescp() {
		return assetDescp;
	}

	public void setAssetDescp(String assetDescp) {
		this.assetDescp = assetDescp;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getManagerId() {
		return managerId;
	}

	public void setManagerId(String managerId) {
		this.managerId = managerId;
	}

	public String getAssetAttach() {
		return assetAttach;
	}

	public void setAssetAttach(String assetAttach) {
		this.assetAttach = assetAttach;
	}

	public String getEffortSavings() {
		return effortSavings;
	}

	public void setEffortSavings(String effortSavings) {
		this.effortSavings = effortSavings;
	}

	public String getDollarSavings() {
		return dollarSavings;
	}

	public void setDollarSavings(String dollarSavings) {
		this.dollarSavings = dollarSavings;
	}

	public String getAssetType() {
		return assetType;
	}

	public void setAssetType(String assetType) {
		this.assetType = assetType;
	}

	public String getAssetCat() {
		return assetCat;
	}

	public void setAssetCat(String assetCat) {
		this.assetCat = assetCat;
	}

	public String getOwners() {
		return owners;
	}

	public void setOwners(String owners) {
		this.owners = owners;
	}

	public String getAssetStatus() {
		return assetStatus;
	}

	public void setAssetStatus(String assetStatus) {
		this.assetStatus = assetStatus;
	}

	@Override
	public String toString() {
		return "Asset [assetId=" + assetId + ", assetTitle=" + assetTitle + ", assetDescp=" + assetDescp
				+ ", projectId=" + projectId + ", managerId=" + managerId + ", assetAttach=" + assetAttach
				+ ", effortSavings=" + effortSavings + ", dollarSavings=" + dollarSavings + ", assetType=" + assetType
				+ ", assetCat=" + assetCat + ", owners=" + owners + ", assetStatus=" + assetStatus + "]";
	}
	
	
}