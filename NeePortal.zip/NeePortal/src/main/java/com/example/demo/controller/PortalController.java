package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Asset;
import com.example.demo.service.impl.AddAssetServiceImpl;

@RestController
@RequestMapping("/Portal")
public class PortalController {
	
	@Autowired
	private AddAssetServiceImpl addAssetService;
	
	@PostMapping(path = "/submit", consumes = "application/json", produces = "application/json")
	public Asset save(@RequestBody Asset asset) {
		System.out.println("At controller "+asset.toString());
		return addAssetService.save(asset);
	}
	
	@PutMapping("/update")
	public Asset update(@RequestBody Asset asset) {
		return addAssetService.update(asset);
	}
	
	@GetMapping("/all")
	public List<Asset> getAllAsset(){
		return addAssetService.getAllAsset();
		}
	
	@GetMapping("/by/{assetId}")
	public Optional<Asset> getAsset(@PathVariable(name = "assetId") String assetId) {
		return addAssetService.getAsset(assetId);
	}

}