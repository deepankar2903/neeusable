package com.example.demo.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.stereotype.Service;

import com.example.demo.model.Asset;
import com.example.demo.repository.AssetRepository;
import com.example.demo.service.AddAssetService;

@Service
public class AddAssetServiceImpl {
	

	@Autowired
	private AssetRepository assetRepository;

	//@Override
	public Asset save(Asset asset) {
		// TODO Auto-generated method stub
		return assetRepository.save(asset);
	}

	//@Override
	public Asset update(Asset asset) {
		// TODO Auto-generated method stub
		return assetRepository.save(asset);
	}

	//@Override
	public List<Asset> getAllAsset() {
		// TODO Auto-generated method stub
		return assetRepository.findAll();
	}

	public Optional<Asset> getAsset(String assetId) {
		return assetRepository.findById(assetId);
	}
}
